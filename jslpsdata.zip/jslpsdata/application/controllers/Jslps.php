
<?php
class Jslps extends CI_Controller {
     function login()
	{
		$this->load->view('login');
    }
    function deshboard()
	{
		$this->load->view('deshboard');
	}

}
?>