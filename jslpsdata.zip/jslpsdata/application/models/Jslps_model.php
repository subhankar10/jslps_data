<?php
class jslps_model extends CI_model(){
    
}


?>